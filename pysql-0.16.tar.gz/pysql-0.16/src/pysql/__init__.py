# -*- coding: utf-8 -*-
"""
Pysql main package
@author: Sébastien Renard (sebastien.renard@digitalfox.org)
@author: Sébastien Delcros (Sebastien.Delcros@gmail.com)
@license:GNU GPL V3
"""