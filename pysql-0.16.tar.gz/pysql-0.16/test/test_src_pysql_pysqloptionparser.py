import unittest

class TestPysqlOptionParser(unittest.TestCase):
    def test_error(self):
        assert False # TODO: implement your test here

    def test_exit(self):
        assert False # TODO: implement your test here

    def test_object_initialization(self):
        assert False # TODO: implement your test here

    def test_parse_args(self):
        assert False # TODO: implement your test here

if __name__ == '__main__':
    unittest.main()
