import unittest

class TestMain(unittest.TestCase):
    def test_main(self):
        assert False # TODO: implement your test here

class TestSetLocale(unittest.TestCase):
    def test_set_locale(self):
        assert False # TODO: implement your test here

class TestParseOptions(unittest.TestCase):
    def test_parse_options(self):
        assert False # TODO: implement your test here

if __name__ == '__main__':
    unittest.main()
