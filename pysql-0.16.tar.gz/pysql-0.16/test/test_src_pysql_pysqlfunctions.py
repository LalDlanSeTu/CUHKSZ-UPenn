import unittest

class TestCount(unittest.TestCase):
    def test_count(self):
        assert False # TODO: implement your test here

class TestCompare(unittest.TestCase):
    def test_compare(self):
        assert False # TODO: implement your test here

class TestCompareTables(unittest.TestCase):
    def test_compare_tables(self):
        assert False # TODO: implement your test here

class TestCompareTableStructure(unittest.TestCase):
    def test_compare_table_structure(self):
        assert False # TODO: implement your test here

class TestCompareTableData(unittest.TestCase):
    def test_compare_table_data(self):
        assert False # TODO: implement your test here

class TestDdl(unittest.TestCase):
    def test_ddl(self):
        assert False # TODO: implement your test here

class TestDesc(unittest.TestCase):
    def test_desc(self):
        assert False # TODO: implement your test here

class TestEdit(unittest.TestCase):
    def test_edit(self):
        assert False # TODO: implement your test here

class TestEditor(unittest.TestCase):
    def test_editor(self):
        assert False # TODO: implement your test here

class TestExplain(unittest.TestCase):
    def test_explain(self):
        assert False # TODO: implement your test here

class TestLock(unittest.TestCase):
    def test_lock(self):
        assert False # TODO: implement your test here

class TestSessions(unittest.TestCase):
    def test_sessions(self):
        assert False # TODO: implement your test here

class TestSessionStat(unittest.TestCase):
    def test_session_stat(self):
        assert False # TODO: implement your test here

class TestKillSession(unittest.TestCase):
    def test_kill_session(self):
        assert False # TODO: implement your test here

class TestShowParameter(unittest.TestCase):
    def test_show_parameter(self):
        assert False # TODO: implement your test here

class TestShowServerParameter(unittest.TestCase):
    def test_show_server_parameter(self):
        assert False # TODO: implement your test here

class TestSearchObject(unittest.TestCase):
    def test_search_object(self):
        assert False # TODO: implement your test here

if __name__ == '__main__':
    unittest.main()
