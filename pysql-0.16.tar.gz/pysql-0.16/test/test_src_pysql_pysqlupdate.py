import unittest

class TestCheckForUpdate(unittest.TestCase):
    def test_check_for_update(self):
        assert False # TODO: implement your test here

class TestCurrentVersion(unittest.TestCase):
    def test_current_version(self):
        assert False # TODO: implement your test here

class TestUpdate(unittest.TestCase):
    def test_update(self):
        assert False # TODO: implement your test here

class TestVersion(unittest.TestCase):
    def test_object_initialization(self):
        assert False # TODO: implement your test here

if __name__ == '__main__':
    unittest.main()
