import unittest

class TestPysqlNotImplemented(unittest.TestCase):
    def test_object_initialization(self):
        assert False # TODO: implement your test here

class TestPysqlActionDenied(unittest.TestCase):
    def test_object_initialization(self):
        assert False # TODO: implement your test here

if __name__ == '__main__':
    unittest.main()
